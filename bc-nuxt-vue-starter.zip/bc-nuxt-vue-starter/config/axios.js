export default {
  baseURL: process.env.BASE_URL || 'http://localhost:3000',
  debug: false,
  proxy: true
};
