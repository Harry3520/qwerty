export default {
  /*
   ** You can extend webpack config here
   */
  transpile: [/^@storefront-ui/]
};
