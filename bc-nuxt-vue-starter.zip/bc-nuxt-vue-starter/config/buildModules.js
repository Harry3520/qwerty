export default ['@nuxtjs/dotenv', '@nuxtjs/pwa'];
