export default [
  {
    src: '~assets/sass/app.scss',
    lang: 'scss'
  },
  '@storefront-ui/vue/styles.scss'
];
