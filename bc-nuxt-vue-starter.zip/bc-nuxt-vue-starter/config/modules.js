export default [
  '@nuxtjs/dotenv',
  '@nuxtjs/axios',
  '@nuxtjs/pwa',
  '@nuxtjs/toast',
  '@nuxtjs/proxy'
];
