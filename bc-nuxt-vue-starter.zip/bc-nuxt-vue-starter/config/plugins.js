export default ['@/plugins/axios', '@/plugins/queries'];
