export default {
  position: 'bottom-left',
  theme: 'custom',
  duration: 2500,
  register: [
    {
      // Register custom toasts
    }
  ]
};
