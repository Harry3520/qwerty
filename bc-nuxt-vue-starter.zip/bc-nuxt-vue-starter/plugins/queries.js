import queries from '@/utils/queries';

export default function (_, inject) {
  inject('queries', queries);
}
